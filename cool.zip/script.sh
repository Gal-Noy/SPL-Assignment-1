#!/bin/sh

make

bin/cRace /tests/shouldTerminate1.json
bin/cRace /tests/shouldTerminate2.json
bin/cRace /tests/lastJoinPolicy1.json
bin/cRace /tests/mandatesJoinPolicly2.json
bin/cRace /tests/mandatesJoinPolicly3.json
bin/cRace tests/EdgeSelectionPolicy1.json
bin/cRace customTests/EdgeSelectionPolicy2.json
bin/cRace customTests/MandatesSelectionPolicy1.json
bin/cRace customTests/MandatesSelectionPolicy2.json

diff -s tests/shouldTerminate1_sol.out tests/shouldTerminate1.out
diff -s tests/shouldTerminate2_sol.out tests/shouldTerminate2.out
diff -s tests/lastJoinPolicy1_sol.out tests/lastJoinPolicy1.out
diff -s tests/mandatesJoinPolicly2_sol.out tests/mandatesJoinPolicly2.out
diff -s tests/mandatesJoinPolicly3_sol.out tests/mandatesJoinPolicly3.out
diff -s tests/EdgeSelectionPolicy1_sol.out tests/EdgeSelectionPolicy1.out
diff -s tests/EdgeSelectionPolicy2_sol.out tests/EdgeSelectionPolicy2.out
diff -s tests/MandatesSelectionPolicy1_sol.out tests/MandatesSelectionPolicy1.out
diff -s tests/MandatesSelectionPolicy2_sol.out tests/MandatesSelectionPolicy2.out